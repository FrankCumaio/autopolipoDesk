-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 04-Jun-2015 às 19:34
-- Versão do servidor: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `autopolipo`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `acessorios`
--

CREATE TABLE IF NOT EXISTS `acessorios` (
  `tipo` varchar(50) NOT NULL,
  `marca` varchar(50) NOT NULL,
  `modelo` varchar(50) NOT NULL,
  `quant` int(10) NOT NULL,
  `preco` int(11) NOT NULL,
  `ID` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `acessorios`
--

INSERT INTO `acessorios` (`tipo`, `marca`, `modelo`, `quant`, `preco`, `ID`) VALUES
('jantes', 'universal', 'universal', 81, 200, 8),
('Calços', 'universal', 'universal', 71, 250, 9),
('Balatas', 'Nissan', 'Bluebird', 50, 300, 10),
('Filtros de Ar', 'Toyota', 'Corolla Runx', 20, 500, 11),
('Oleo de Motor(Gasolina)', 'Honda', 'Accord', 3, 2500, 12),
('Lampadas', 'universal', 'universal', 97, 500, 13);

-- --------------------------------------------------------

--
-- Estrutura da tabela `arquivo`
--

CREATE TABLE IF NOT EXISTS `arquivo` (
  `ID` int(10) NOT NULL,
  `marca` varchar(20) NOT NULL,
  `modelo` varchar(50) NOT NULL,
  `matricula` varchar(50) NOT NULL,
  `proprietario` text NOT NULL,
  `preco` int(50) NOT NULL,
  `observacao` varchar(50) NOT NULL,
  `action` text,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `arquivo`
--

INSERT INTO `arquivo` (`ID`, `marca`, `modelo`, `matricula`, `proprietario`, `preco`, `observacao`, `action`) VALUES
(4, 'Toyota', 'Avensis', 'aef 556 dm', 'inercio', 0, '', NULL),
(18, 'BMW', '6 Series', 'ABU-510-MP', 'boisse kito', 2000, '', NULL),
(19, 'Toyota', 'Avensis', 'ABW-521-MP', 'inercio', 5500, '', NULL),
(20, 'Nissan', 'Homy', 'ABH-478-MP', 'rozay', 2750, '', NULL),
(21, 'Honda', 'HR-v', 'AEU-127-MP', 'wilson Mafas', 2250, '', NULL),
(22, 'Mercedes', 'GLK-Class', 'ABW-574-MP', 'inercio', 2250, '', NULL),
(23, 'Toyota', 'Avensis', 'ABW-521-MP', 'boisse kito', 2250, '', NULL),
(24, 'Audi', 'A8', 'ABF-541-MP', 'inercio', 2250, '', NULL),
(25, 'Nissan', 'Atlas', 'ABU-256-MP', 'wilson Mafas', 2250, '', NULL),
(26, 'Nissan', 'Datsun', 'MMJ-092-23', 'Ataide chilaule', 2250, '', NULL),
(27, 'Honda', 'Fit', 'ABW-587-MP', 'rozay', 2250, '', NULL),
(28, 'Honda', 'Accord', 'AEF-111-mp', 'Inercio Belton', 3000, '', NULL),
(29, 'Toyota', 'Altezza', 'ABU-589-MP', 'inercio', 2500, '', NULL),
(30, 'Subaru', 'Impreza', 'Abhhhh', 'Douglas', 2250, '', NULL),
(31, 'Nissan', 'Fairlady Z', 'MMMMM', 'inercio', 2500, '', NULL),
(32, 'Mercedes', 'CLK-Class', 'ABU-510-MP', 'inercio', 2500, '', NULL),
(34, 'Honda', 'CR-V', 'MMMM', 'rozay', 3500, '', NULL),
(35, 'Audi', 'A8', 'LLLjjk', 'Douglas', 1250, '', NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `aux`
--

CREATE TABLE IF NOT EXISTS `aux` (
  `acessorio` varchar(50) NOT NULL,
  `preco` int(50) NOT NULL,
  `quant` int(50) NOT NULL,
  `pagar` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `carrinho`
--

CREATE TABLE IF NOT EXISTS `carrinho` (
  `acessorio` varchar(50) NOT NULL,
  `preco` int(50) NOT NULL,
  `quant` int(50) NOT NULL,
  `pagar` int(50) NOT NULL,
  KEY `acessorio` (`acessorio`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `carrinho`
--

INSERT INTO `carrinho` (`acessorio`, `preco`, `quant`, `pagar`) VALUES
('Mao de obra', 2000, 1, 2000);

-- --------------------------------------------------------

--
-- Estrutura da tabela `clientes`
--

CREATE TABLE IF NOT EXISTS `clientes` (
  `ID` int(6) NOT NULL,
  `tipocliente` text NOT NULL,
  `nome` text NOT NULL,
  `bi` varchar(20) NOT NULL,
  `morada` varchar(50) NOT NULL,
  `contacto` int(25) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `clientes`
--

INSERT INTO `clientes` (`ID`, `tipocliente`, `nome`, `bi`, `morada`, `contacto`) VALUES
(5, 'Pessoal', 'Autumn Tatics', '10001000051', 'Matola', 845454845),
(6, 'pessoal', 'wilson Mafas', '100050554', 'matola', 84),
(112, 'Pessoal', 'rozay', '9785698685j', 'fsdf', 22),
(2124, 'Pessoal', 'inercio', '84584654g', 'mahotas', 1111),
(2125, 'Pessoal', 'Douglas', '211005iuytt', 'fomento', 842562416),
(2126, 'Pessoal', 'rozay boss', '13234jhgkk', 'fometno', 87841848),
(2127, 'Empresarial', 'jhadsiue', 'dfsfd454', 'ugiiuy', 888),
(2129, 'Empresarial', 'boisse kito', 'coisa de boss7', 'ele e boss nao interessa', 0),
(2133, 'Pessoal', 'Ataide chilaule', '100010110jgk', 'matola c700', 842562111),
(2134, 'Pessoal', 'Inercio Belton', '8465845648F', 'Bairro das Mahotas', 84562);

-- --------------------------------------------------------

--
-- Estrutura da tabela `oficina`
--

CREATE TABLE IF NOT EXISTS `oficina` (
  `ID` int(6) NOT NULL,
  `marca` text NOT NULL,
  `modelo` varchar(20) NOT NULL,
  `matricula` varchar(20) NOT NULL,
  `proprietario` text NOT NULL,
  `avaria` text NOT NULL,
  `observacao` text NOT NULL,
  `alteracao` text,
  PRIMARY KEY (`ID`),
  KEY `ID` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `oficina`
--

INSERT INTO `oficina` (`ID`, `marca`, `modelo`, `matricula`, `proprietario`, `avaria`, `observacao`, `alteracao`) VALUES
(1, 'Nissan', 'Bluebird', 'hhh', 'rozay', 'Electrica', '', 'confirmar');

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuario`
--

CREATE TABLE IF NOT EXISTS `usuario` (
  `username` text NOT NULL,
  `senha` varchar(6) NOT NULL,
  `nome` text NOT NULL,
  `ID` int(8) NOT NULL,
  `activo` tinyint(1) DEFAULT NULL,
  `Tipo` varchar(50) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `usuario`
--

INSERT INTO `usuario` (`username`, `senha`, `nome`, `ID`, `activo`, `Tipo`) VALUES
('frank', 'frank1', 'frank cumaio', 1, 0, 'Administrador'),
('Inercio', '123', 'Inercio Belton', 2, 0, 'Administrador');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
